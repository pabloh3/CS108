package edu.cs108.stanford.shippingcalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import java.lang.Math;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calculate (View view) {
        //find all elements
        EditText editText = findViewById(R.id.editText);
        RadioButton nextDay = findViewById(R.id.nextDay);
        RadioButton secondDay = findViewById(R.id.secondDay);
        RadioButton standard = findViewById(R.id.standard);
        CheckBox insurance = findViewById(R.id.insurance);
        TextView cost = findViewById(R.id.cost);

        //check if editText is empty
        if (editText.getText().toString().trim().length() == 0) {
            //do nothing
        } else {
            //extract editText and turn to double
            String text = editText.getText().toString();
            double weight = Double.parseDouble(text);
            double price;
            //set price based on delivery day
            if (nextDay.isChecked()) {
                price = weight * 10;
            } else if (secondDay.isChecked()) {
                price = weight * 5;
            } else {
                price = weight * 3;
            }

            //add insurance price
            if (insurance.isChecked()) {
                price = price * 1.2;
            }

            //round up price and return cost, empty editText
            int intPrice = (int) Math.ceil(price);
            cost.setText("Cost: $" + intPrice);
            editText.setText("");
        }
    }
}
